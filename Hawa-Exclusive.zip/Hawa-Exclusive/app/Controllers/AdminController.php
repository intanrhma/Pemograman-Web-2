<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController
{
    public function index()
    {
        return view('admin/dashboard');
    }
    public function koleksiproduk()
    {
        $modelProduk = model('ProdukModel');
        $data['products'] = $modelProduk->findAll();

        return view('admin/koleksi-produk', $data);
    }
    public function koleksiprodukTambah()
    {
        return view('admin/koleksi-produk-tambah');
    }
    public function createProduk(){
        $data = $this->request->getPost();
        $file = $this->request->getFile('katalog');

        if(!$file->hasMoved()){
            $path = $file->store();
            $data['katalog'] = $path;
        }

        $produkModel = model('produkModel');

        if($produkModel->insert($data, false)){
            return redirect()->to('admin/koleksi-produk')->with('sukses', 'data berhasil disimpan');
        }else{
            return redirect()->to('admin/koleksi-produk')->with('eror', 'data gagal disimpan');
        }

        $produkModel->save($data);
    }
    

    // Fungsi untuk menampilkan halaman edit produk
    public function edit($id_produk)
    {
        // Load model
        $ProdukModel = new \App\Models\ProdukModel();
    
        // Ambil data barang berdasarkan ID
        $data['produk'] = $ProdukModel->find($id_produk);
    
        // Jika data tidak ditemukan
        if (!$data['produk']) {
            return redirect()->to('/admin/koleksiproduk')->with('error', 'Barang tidak ditemukan');
        }
    
        // Tampilkan form edit
        return view('admin/koleksiproduk-edit', $data);
    }
    
    public function update($id_produk)
    {
        // Validasi input
        $validation = \Config\Services::validation();
        $validation->setRules([
            'nama_produk' => 'required',
            'brand'    => 'required',
            'katalog'      => 'is_image[katalog]|mime_in[gambar,image/jpg,image/jpeg,image/png]',
	    'harga'       => 'required|numeric'
        ]);
    
        if (!$this->validate($validation->getRules())) {
            return redirect()->back()->withInput()->with('error', $validation->listErrors());
        }
    
        // Load model
        $ProdukModel = new \App\Models\ProdukModel();
    
        // Data untuk di-update
        $data = [
            'nama_produk' => $this->request->getPost('nama_produk'),
            'brand'    => $this->request->getPost('brand'),
            'harga'       => $this->request->getPost('harga'),
        ];
    
        // Jika ada katalog baru yang diunggah
        $fileGambar = $this->request->getFile('katalog');
        if ($fileGambar && $fileGambar->isValid()) {
            $fileName = $fileGambar->getRandomName();
            $fileGambar->move('file-images', $fileName);
            $data['katalog'] = $fileName;
        }
    
        // Update data
        if ($ProdukModel->update($id_produk, $data)) {
            return redirect()->to('/admin/koleksiproduk')->with('sukses', 'Data berhasil diperbarui');
        } else {
            return redirect()->to('/admin/koleksiproduk')->with('error', 'Data gagal diperbarui');
        }
    }
   // Fungsi untuk menghapus produk
public function hapus($id_produk)
{
    // Load model
    $ProdukModel = new \App\Models\ProdukModel();

    // Cek apakah data dengan ID tersebut ada
    $produk = $ProdukModel->find($id_produk);

    if (!$produk) {
        // Jika produk tidak ditemukan, redirect dengan pesan error
        return redirect()->to('/admin/koleksiproduk')->with('error', 'Data tidak ditemukan');
    }

    // Hapus katalog dari folder (jika ada dan file benar-benar ada)
    $file_path = WRITEPATH . 'uploads/file-images/' . $produk['katalog']; // Pastikan folder sudah tepat
    if (isset($produk['katalog']) && $produk['katalog'] && file_exists($file_path)) {
        if (!unlink($file_path)) {
            // Jika gagal menghapus file, beri pesan error
            return redirect()->to('/admin/koleksiproduk')->with('error', 'Gagal menghapus file katalog');
        }
    }

    // Hapus data dari database
    if ($ProdukModel->delete($id_produk)) {
        // Jika penghapusan sukses, beri pesan sukses
        return redirect()->to('/admin/koleksiproduk')->with('sukses', 'Data berhasil dihapus');
    } else {
        // Jika gagal menghapus data dari database, beri pesan error
        return redirect()->to('/admin/koleksiproduk')->with('error', 'Data gagal dihapus');
    }
}

    public function transaksi()
    {
        return view('admin/transaksi');
    }
    public function transaksiUbahStatus()
    {
        return view('admin/transaksi-ubah-status');
    }
    public function transaksiHapus()
    {
        return view('admin/transaksi-hapus');
    }
    public function pelanggan()
    {
        return view('admin/pelanggan');
    }
    public function pelangganHapus()
    {
        return view('admin/pelanggan-hapus');
    }

    public function images($folder, $file){
        return $this->response->download(WRITEPATH . 'uploads/' . $folder . '/' . $file, null);
    }
}