<?= $this->extend('template') ?>

<?= $this->section('main') ?>

<div class="container py-5">
    <!-- Header -->
    <div class="row mb-5">
        <div class="col-12 text-center">
            <h2 class="display-4 text-primary fw-bold">Review Order</h2>
            <p class="text-muted fs-5">Pastikan semua detail pesanan Anda sudah benar sebelum melanjutkan pembayaran.</p>
        </div>
    </div>

    <!-- Product Information -->
    <div class="row align-items-center mb-4 p-3 border rounded bg-light shadow-sm">
        <div class="col-3 text-center">
            <img src="<?= base_url('Images/abaya.jpg') ?>" alt="Haniya Abaya Set" class="img-fluid rounded">
        </div>
        <div class="col-6">
            <h5 class="fw-semibold text-dark mb-1">Haniya Abaya Set</h5>
            <p class="text-muted mb-0">Qty: 1</p>
        </div>
        <div class="col-3 text-end">
            <h5 class="fw-bold text-primary">Rp 638,000</h5>
        </div>
    </div>

    <!-- Separator -->
    <hr class="my-4 border-secondary" />

    <!-- Shipping Address -->
    <div class="row mb-5">
        <div class="col-12">
            <h4 class="fw-bold text-dark">Alamat Pengiriman</h4>
            <p class="text-muted fs-5 mb-0">Jambi Luar Kota</p>
            <p class="text-muted fs-5">Mendalo Asri</p>
        </div>
    </div>

    <!-- Separator -->
    <hr class="my-4 border-secondary" />

    <!-- Payment Method -->
    <div class="row mb-5">
        <div class="col-12">
            <h4 class="fw-bold text-dark">Metode Pembayaran</h4>
            <p class="text-muted fs-5 mb-1">Transfer Bank</p>
            <p class="text-dark fs-5 mb-1">MANDIRI a/n Gissel</p>
            <p class="text-muted fs-5">Rek. 0838000000</p>
        </div>
    </div>

    <!-- Separator -->
    <hr class="my-4 border-secondary" />

    <!-- Total -->
    <div class="row justify-content-center mt-4">
        <div class="col-12 col-md-8 p-4 border rounded bg-light shadow-sm">
            <div class="row align-items-center">
                <div class="col-6">
                    <h4 class="fw-bold text-dark">Total</h4>
                </div>
                <div class="col-6 text-end">
                    <h4 class="fw-bold text-primary">Rp 638,000</h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Separator -->
    <hr class="my-4 border-secondary" />

    <!-- Submit Order -->
    <div class="row justify-content-center mt-4">
        <div class="col-12 col-md-6">
            <form action="<?= base_url('submit') ?>" method="POST">
                <button type="submit" class="btn btn-success btn-lg w-100 shadow-sm">Submit Order</button>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
