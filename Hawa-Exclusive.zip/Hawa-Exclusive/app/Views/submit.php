<?= $this->extend('template') ?>

<?= $this->section('main') ?>

<div class="container">
    <!-- Success Message Section -->
    <div class="py-5 text-center">
        <!-- Alert Box with Custom Styling -->
        <div class="alert alert-success rounded-3 shadow-sm" style="background-color: #e8f5e9; border: 1px solid #81c784; color: black;">
            <strong>BERHASIL!</strong> ORDER ANDA AKAN SEGERA DI PROSES
        </div>

        <!-- Navigation Button Section -->
        <div class="mt-5">
            <a href="<?= base_url() ?>" class="btn btn-lg btn-black text-black shadow-sm">Kembali Berbelanja</a>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<!-- Add this to your CSS file or within a <style> tag in the view -->
<style>
    /* Soft background for the entire page */
    body {
        background-color: #fce4ec; /* Soft pink background */
    }

    /* Style for the alert box to make it more visually appealing */
    .alert {
        background-color: #e8f5e9; /* Light green for success alert */
        border: 1px solid #81c784; /* Soft border color */
        color: black; /* Changed font color to black */
        padding: 20px;
        border-radius: 15px;
        font-size: 1.1rem;
    }

    /* Styling for the action button */
    .btn-pink {
        background-color: #f06292; /* Soft pink background */
        border-color: #f06292;
        padding: 12px 30px;
        font-size: 1.1rem;
        border-radius: 25px;
    }

    /* Hover effect for button */
    .btn-pink:hover {
        background-color: #ec407a; /* Darker pink on hover */
        border-color: #ec407a;
    }

    /* Button text color */
    .btn-pink, .btn-pink:hover {
        color: black; /* Set button text color to black */
    }
</style>
