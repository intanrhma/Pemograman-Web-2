<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Keranjang Belanja - Toko Hawa Exclusive</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
      body {
        background-color: #fff; /* White background */
        color: #000; /* Black text for all text */
      }
      .bg-soft-pink {
        background-color: #fce4ec !important; /* Even softer pastel pink for sections */
      }
      .text-soft-pink {
        color: #f48fb1 !important; /* Lighter, more pastel soft pink text color */
      }
      .btn-soft-pink {
        background-color: #f48fb1;
        color: white;
      }
      .btn-soft-pink:hover {
        background-color: #f06292; /* Slightly darker pink on hover */
      }
      .bg-light-soft-pink {
        background-color: #fce4ec;
      }
      .text-dark-soft {
        color: #333333 !important; /* Darker soft gray for more readability */
      }
      .fw-bold {
        font-weight: bold;
      }
      .text-muted {
        color: #555; /* Muted text in a softer black */
      }
    </style>
  </head>
  <body>
    <div class="container py-4">
      <!-- Header -->
      <div class="row bg-soft-pink py-3 mb-4 rounded text-center">
        <div class="col-12">
          <h1 class="text-dark-soft">Keranjang Belanja</h1>
        </div>
      </div>

      <!-- Navigation -->
      <div class="row mb-4">
        <div class="col-12 d-flex justify-content-end">
          <a href="chart.php" class="btn btn-soft-pink">
            Keranjang Belanja 
            <span class="badge bg-warning text-dark">1</span>
          </a>
        </div>
      </div>

      <!-- Products -->
      <div class="row g-3">
        <!-- Product Template -->
        <div class="col-12">
          <div class="row p-3 bg-light-soft-pink border rounded align-items-center">
            <div class="col-3">
              <img src="<?= base_url('Images/abaya.jpg') ?>" alt="Haniya Abaya - Lozy" class="img-fluid rounded">
            </div>
            <div class="col-5">
              <h5 class="mb-1 text-dark-soft">Haniya Abaya - Lozy</h5>
              <p class="mb-0 text-muted">Rp 319,000</p>
            </div>
            <div class="col-2 text-center">
              <span class="fw-bold text-soft-pink">Qty: 1</span>
            </div>
            <div class="col-2 text-center">
              <a href="#" class="btn btn-danger">Hapus</a>
            </div>
          </div>
        </div>

        <!-- Product Template (Duplicate for additional products) -->
        <div class="col-12">
          <div class="row p-3 bg-light-soft-pink border rounded align-items-center">
            <div class="col-3">
              <img src="<?= base_url('Images/abaya.jpg') ?>" alt="Haniya Abaya - Lozy" class="img-fluid rounded">
            </div>
            <div class="col-5">
              <h5 class="mb-1 text-dark-soft">Haniya Abaya - Lozy</h5>
              <p class="mb-0 text-muted">Rp 319,000</p>
            </div>
            <div class="col-2 text-center">
              <span class="fw-bold text-soft-pink">Qty: 1</span>
            </div>
            <div class="col-2 text-center">
              <a href="#" class="btn btn-danger">Hapus</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Total and Actions -->
      <div class="row mt-5">
        <div class="col-12 text-end mb-3">
          <h3 class="fw-bold text-dark-soft">Total: Rp 638,000</h3>
        </div>
        <div class="col-12 text-end">
          <a href="<?= base_url() ?>" class="btn btn-soft-pink">Kembali Berbelanja</a>
          <a href="<?= base_url('checkout') ?>" class="btn btn-primary">Checkout</a>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
