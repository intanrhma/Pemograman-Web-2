<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Toko Hawa Exclusive menyediakan pakaian Muslimah dari berbagai brand terkenal.">
    <title>Toko Hawa Exclusive</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= base_url() ?>css/style.css">
  </head>
  <body>

    <div class="container">
        <div class="row mb-5">
            <div class="col-12 text-end">
                <a href="<?= base_url() ?>chart" class="btn btn-info">Keranjang Belanja <span class="badge bg-warning">2</span></a>
            </div>
        </div>
        
        <!-- Welcome Section -->
        <div class="row welcome-section mb-5 align-items-center">
            <div class="col-md-6">
                <h1>Selamat Datang di Hawa Exclusive</h1>
                <p>Kami menyediakan pakaian Muslimah dari berbagai brand terkenal.</p>
                <a href="#" class="btn btn-success">Lihat Koleksi Kami</a>
            </div>
            <div class="col-md-6">
                <h2>Cari Pakaian Muslimah Favoritmu</h2>
                <form action="" method="get">
                    <div class="mb-3">
                        <input type="text" class="form-control" name="search" placeholder="Cari Koleksi" aria-label="Cari Koleksi">
                    </div>
                    <div class="mb-3">
                        <button class="btn btn-primary" type="submit">Cari</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Best Seller Products Section -->
        <h2 class="text-center mb-5">Produk Best Seller di Hawa Exclusive</h2>
        <div class="row justify-content-center g-3 mb-5">
            <!-- Example of repeated product cards -->
            <?php 
                // Loop through products (dummy example here)
                 { 
            ?>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/BaniBatuta.jpg" class="card-img-top" alt="Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Bani Batuta - Rabbani</h5>
                        <p class="card-text">Rp.419,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/sairaabaya.jpg" class="card-img-top" alt="Saira Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Saira Abaya - Lozy</h5>
                        <p class="card-text">Rp.519,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/abaya.jpg" class="card-img-top" alt="Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Haniya Abaya - Lozy</h5>
                        <p class="card-text">Rp.319,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/dresslimameliaexclusive.jpg" class="card-img-top" alt="Rabbani">
                    <div class="card-body">
                        <h5 class="card-title">Dresslim Amelia - Rabbani</h5>
                        <p class="card-text">Rp.419,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/shameera.jpg" class="card-img-top" alt="Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Shameera Abaya - Lozy</h5>
                        <p class="card-text">Rp.719,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/sadia.jpg" class="card-img-top" alt="Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Sadia Abaya - Lozy</h5>
                        <p class="card-text">Rp.599,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/PashminaKaosRayon.jpg" class="card-img-top" alt="Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Pashmina Kaos Rayon - Lozy</h5>
                        <p class="card-text">Rp.99,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/harumidress.jpg" class="card-img-top" alt="Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Harumi Dress - Lozy</h5>
                        <p class="card-text">Rp.369,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/HijabSportJersey.jpg" class="card-img-top" alt="Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Hijab Sport Jersey - Lozy</h5>
                        <p class="card-text">Rp.39,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <img src="<?= base_url() ?>Images/HijabRaynaInstanSquare.jpg" class="card-img-top" alt="Abaya - Lozy">
                    <div class="card-body">
                        <h5 class="card-title">Hijab Rayna Instan Square - Lozy</h5>
                        <p class="card-text">Rp.99,000,-</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>

    <footer class="bg-warning text-center py-3 mt-4">
        <div class="container">
            &copy; 2024, Toko Hawa Exclusive. All Rights Reserved.
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
